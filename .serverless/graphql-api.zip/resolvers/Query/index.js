'use strict';
const TodoQuery = require('./TodoQuery');

module.exports = {
  ...TodoQuery
};
